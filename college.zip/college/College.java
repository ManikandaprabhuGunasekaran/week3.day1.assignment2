package org.college;

public class College {

	public void collegeName() {
		System.out.println("This method is for CollegeName");
	}

	public void collegeCode() {
		System.out.println("This method is for CollegeCode");
	}

	public void collegeRank() {
		System.out.println("This method is for CollegeRank");
	}
}
