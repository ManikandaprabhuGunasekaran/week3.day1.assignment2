package org.student;

import org.department.Department;

public class Student extends Department {
	
	public static void main(String[] args) {
		
		Student st=new Student();
		st.collegeName();
		st.collegeCode();
		st.collegeRank();
		System.out.println("---------------");
		
		st.deptName();
		System.out.println("---------------");
		
		st.studentName();
		st.studentId();
		st.studentDept();
	}

	public void studentName() {
		System.out.println("This method is for Student Name");
	}

	public void studentDept() {
		System.out.println("This method is for Student Dept");
	}

	public void studentId() {
		System.out.println("This method is for Student Id");
	}
}
